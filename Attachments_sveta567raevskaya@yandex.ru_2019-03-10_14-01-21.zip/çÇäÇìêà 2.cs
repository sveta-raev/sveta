﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   
    
       internal class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Эта программа поможет вам подобрать фильм который вам по душе");
                Console.WriteLine("Как вас зовут ,Искатель фильмов ?");
                String Name = Console.ReadLine();
                Console.WriteLine("Приветствую, " + Name);
                Console.WriteLine("Фильм какого жанра вы бы хотели бы посмотреть  :Комедию или Ужасы?");
                String Text = Console.ReadLine();
                if (Text == "ужасы")
                {
                    Console.WriteLine("* Зеркала");
                    Console.WriteLine("* Астрал");
                    Console.WriteLine("* Окулус ");
                    Console.WriteLine("* Пираньи");
                    Console.WriteLine("* Другой мир");
                }
                else
                {
                    Console.WriteLine("* Пауки");
                    Console.WriteLine("* Укус");
                    Console.WriteLine("* Коллекционер");
                    Console.WriteLine("* Звонок");
                    Console.WriteLine("* Крик");
                }

                Console.ReadLine();
            }
        }

    }


  

