﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{

}
        private class Program
        {
    public Program()
    {
    }

    static void Main(string[] args)
        {
            GraphicsWindow.KeyDown += GraphicsWindow_KeyDown;

            Turtle.PenUp(); GraphicsWindow.BrushColor = "Red"; var food = Shapes.AddRectangle(10, 10); var foodX = 200; var foodY = 200; Shapes.Move(food, foodX, foodY); while (true) { Turtle.Move(10); if (Turtle.X >= foodX && Turtle.Y >= foodY && Turtle.X <= foodX + 10 && Turtle.Y <= foodY + 10) { foodX += 10; Shapes.Move(food, foodX, foodY); } }
        }
        private static void GraphicsWindow_KeyDown() { if (GraphicsWindow.LastKey == "Up") { Turtle.Angle = 0; } else if (GraphicsWindow.LastKey == "Down") { Turtle.Angle = 180; } else if (GraphicsWindow.LastKey == "Left") { Turtle.Angle = 270; } else if (GraphicsWindow.LastKey == "Right") { Turtle.Angle = 90; } }

            private class Shapes
            {
                internal static object AddRectangle(int v1, int v2)
                {
                    throw new NotImplementedException();
                }

                internal static void Move(object food, int foodX, int foodY)
                {
                    throw new NotImplementedException();
                }
            }
        }

    internal class Turtle
    {
            internal static int Angle;

            public static int X { get; internal set; }
            public static int Y { get; internal set; }

            internal static void Move(int v)
            {
                throw new NotImplementedException();
            }

            internal static void PenUp()
        {
            throw new NotImplementedException();
        }
    }

    internal class GraphicsWindow
    {
        internal static Action KeyDown;
        internal static string BrushColor;

        public static string LastKey { get; internal set; }
    }




