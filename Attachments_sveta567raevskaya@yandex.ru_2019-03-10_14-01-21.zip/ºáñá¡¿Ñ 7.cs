﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{

    namespace TurtleGame
    {
        class Program
        {
            private static void Main()
            {
                int GraphicsWindow_KeyDown = 0;
                GraphicsWindow.KeyDown += GraphicsWindow_KeyDown;
                Turtle.PenUp();

                GraphicsWindow.BrushColor = "Red"; var eat = Shapes.AddRectangle(10, 10); var eatPositionX = 200; var eatPositionY = 200; var TurtlePositionX = 300; var TurtlePositionY = 200; Turtle.X = TurtlePositionX; Turtle.Y = TurtlePositionY; Shapes.Move(eat, eatPositionX, eatPositionY); Turtle.TurnLeft(); //иначе я на тесте долго гоняюсь за первым кусочком(( Random rand = new Random(); while (true) { Turtle.Move(10); if (Turtle.X >= eatPositionX && Turtle.X <= eatPositionX + 10 && Turtle.Y >= eatPositionY && Turtle.Y <= eatPositionY + 10) { eatPositionX = rand.Next(0, GraphicsWindow.Width); eatPositionY = rand.Next(0, GraphicsWindow.Height); Shapes.Move(eat, eatPositionX, eatPositionY); Turtle.Speed = Turtle.Speed + 1; } } } private static void GraphicsWindow_KeyDown() { if(GraphicsWindow.LastKey == "Up") { Turtle.Angle = 0; } else if(GraphicsWindow.LastKey == "Right") { Turtle.Angle = 90; } else if (GraphicsWindow.LastKey == "Down") { Turtle.Angle = 180; } else if (GraphicsWindow.LastKey == "Left") { Turtle.Angle = 270; } } } 
            }


            internal class GraphicsWindow
            {
                internal static string BrushColor;

                public static int KeyDown { get; internal set; }
            }

            internal class Turtle
            {
                public static int X { get; internal set; }
                public static int Y { get; internal set; }

                internal static void PenUp()
                {
                    throw new NotImplementedException();
                }

                internal static void TurnLeft()
                {
                    throw new NotImplementedException();
                }
            }

            internal class Shapes
            {
                internal static object AddRectangle(int v1, int v2) => throw new NotImplementedException();

                internal static void Move(object eat, int eatPositionX, int eatPositionY) => throw new NotImplementedException();

                public override bool Equals(object obj)
                {
                    return base.Equals(obj);
                }

                public override int GetHashCode()
                {
                    return base.GetHashCode();
                }

                public override string ToString()
                {
                    return base.ToString();
                }
            }
        }
    }
}

  

                
            

    