﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Эта программа поможет подобрать вам фильм для вечернего просмотра");
        Console.WriteLine("Как вас зовут?");
        String name = Console.ReadLine();

        Console.WriteLine("Здравствуйте," + name); Console.WriteLine("Фильм какого жанра вы бы хотели посмотреть: комедия, мелодрама"); String genre = Console.ReadLine(); Console.WriteLine("В Таком случае, рекомендую вам посмотреть следующие фильмы:"); if (genre == "комедия") { Console.WriteLine("* Я худею"); Console.WriteLine("* такси"); Console.WriteLine("* Ирония судьбы или с легким паром"); Console.WriteLine("*Бриллиантовая рука"); Console.WriteLine("* Один дома"); Console.WriteLine("* Дедушка легкого поведеия"); Console.WriteLine("* 1+1"); Console.WriteLine("* Назад в будущее"); Console.WriteLine("* Операция Ы и другие приключения Шурика"); Console.WriteLine("* Иван Василич меняет профессию"); Console.WriteLine("* В джазе только девушки"); } else if (genre == "меллодрама") { Console.WriteLine("* красавица для чудовища"); Console.WriteLine("* до встречи с тобой"); Console.WriteLine("* если я останусь"); } else { Console.WriteLine("Таких фильмов у нас нет !"); }
        Console.ReadLine();
    }
} 

}
