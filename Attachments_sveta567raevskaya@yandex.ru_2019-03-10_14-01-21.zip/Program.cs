﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {

    }
        }
internal class Turtle 
    {
    private static int Angle;
    private static int X;
    private static int Y;
    private static int Speed;

    static void WriteT()
        {
            //буква Т
            Turtle.Angle = 0;
            Turtle.Move(60);
            Turtle.Turn(-90);
            Turtle.Move(20);
            Turtle.Turn(180);
            Turtle.Move(40);

        }

    private static void Turn(int v)
    {
        throw new NotImplementedException();
    }

    private static void Move(int v)
    {
        throw new NotImplementedException();
    }

    static void WriteO(int size) { Turtle.Angle = 0; for (int i = 0; i < 4; i++) { Turtle.Move(size); Turtle.TurnRight(); } }

    private static void TurnRight()
    {
        throw new NotImplementedException();
    }

    static void WriteP() { Turtle.Angle = 0; Turtle.Move(60); Turtle.TurnRight(); Turtle.Move(30); Turtle.TurnRight(); Turtle.Move(30); Turtle.TurnRight(); Turtle.Move(30); }
        static void Main(string[] args)
        {
            Turtle.X = 200; Turtle.Y = 200; Turtle.Speed = 8;
        }
    }


        // ТОРТ WriteT(); Turtle.X = 260; Turtle.Y = 200; WriteO(60); Turtle.X = 340; Turtle.Y = 200; WriteP(); Turtle.X = 420; Turtle.Y = 200; WriteT();{ Turtle.X = 200; Turtle.Y = 200; Turtle.Speed = 8; // ТОРТ WriteT(); Turtle.X = 260; Turtle.Y = 200; WriteO(60); Turtle.X = 340; Turtle.Y = 200; WriteP(); Turtle.X = 420; Turtle.Y = 200; WriteT();


